import asyncio
import logging
import random
from asyncua import Server, ua


async def main():
    _logger = logging.getLogger("asyncua")
    # setup our server
    server = Server()
    await server.init()
    server.set_endpoint("opc.tcp://0.0.0.0:4840/freeopcua/server/")

    # setup our own namespace, not really necessary but should as spec
    uri = "http://examples.freeopcua.github.io"
    idx = await server.register_namespace(uri)
    ns = "ns=2;s=shopfloor.moldingPress.pressure"
    ns2 = "ns=2;s=shopfloor.moldingPress.temperature"
    ns3 = "ns=2;s=shopfloor.moldingPress.cycle"
    ns4 = "ns=2;s=shopfloor.drillingMachine.rpm"
    ns5 = "ns=2;s=shopfloor.drillingMachine.temperature"
    
    min_val_pressure = -0.5
    max_val_pressure = 0.5
    min_val_temperature = -1.0
    max_val_temperature = 1.0
    min_val_rpm = -100.0
    max_val_rpm = 100.0
    const_val_cycle = 500.0

    # populating our address space
    # server.nodes, contains links to very common nodes like objects and root
    myobj = await server.nodes.objects.add_object(idx, "MyShopfloor")
    mpPressure = await myobj.add_variable(ns, "MyMoldingPress", 5.0)
    mpTemperature = await myobj.add_variable(ns2, "MyMoldingPress", 30.0)
    mpCycle = await myobj.add_variable(ns3, "MyMoldingPress", 10000.0)
    dmRPM = await myobj.add_variable(ns4, "MyDrilingMachine", 8500.0)
    dmTemperature = await myobj.add_variable(ns5, "MyDrillingMachine", 50.0)
    # Set MyVariable to be writable by clients
    await mpPressure.set_writable()
    await mpTemperature.set_writable()
    await mpCycle.set_writable()
    await dmRPM.set_writable()
    await dmTemperature.set_writable()
    opcs = [ mpPressure, mpTemperature, mpCycle, dmRPM, dmTemperature ]
  
    _logger.info("Starting server!")
    async with server:
        while True:
            await asyncio.sleep(1)
            for opc in opcs:
                if str(opc) == 'ns=2;s=shopfloor.drillingMachine.rpm':
                    random_counter = random.uniform(min_val_rpm, max_val_rpm)
                    new_val = await opc.get_value() + random_counter
                    if(new_val>10000.0):
                        new_val=10000.0
                    elif(new_val<7000.0):
                        new_val=7000.0
                    _logger.info("Set value of %s to %.1f", opc, new_val)
                    await opc.write_value(new_val)
                if str(opc) == 'ns=2;s=shopfloor.moldingPress.pressure':
                    random_counter = random.uniform(min_val_pressure, max_val_pressure)
                    new_val = await opc.get_value() + random_counter
                    if(new_val>10.0):
                        new_val=10.0
                    elif(new_val<0.0):
                        new_val=0.0
                    _logger.info("Set value of %s to %.1f", opc, new_val)
                    await opc.write_value(new_val)
                if str(opc) == 'ns=2;s=shopfloor.moldingPress.cycle':
                    new_val = await opc.get_value() + const_val_cycle
                    if(new_val>50000.0):
                        new_val=10000.0
                    _logger.info("Set value of %s to %.1f", opc, new_val)
                    await opc.write_value(new_val)
                if str(opc) == 'ns=2;s=shopfloor.moldingPress.temperature':
                    random_counter = random.uniform(min_val_temperature, max_val_temperature)
                    new_val = await opc.get_value() + random_counter
                    if(new_val>40.0):
                        new_val=40.0
                    elif(new_val<20.0):
                        new_val=20.0
                    _logger.info("Set value of %s to %.1f", opc, new_val)
                    await opc.write_value(new_val)
                if str(opc) == 'ns=2;s=shopfloor.drillingMachine.temperature':
                    random_counter = random.uniform(min_val_temperature, max_val_temperature)
                    new_val = await opc.get_value() + random_counter
                    if(new_val>60.0):
                        new_val=60.0
                    elif(new_val<40.0):
                        new_val=40.0
                    _logger.info("Set value of %s to %.1f", opc, new_val)
                    await opc.write_value(new_val)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    asyncio.run(main(), debug=True)